// Chapter 1

// 1.
alert('Wlecome to our website how are you?')

// 2
alert('Error! Enter a valid password')

// 3
alert('Welcome to JS land \n Happy Coding!')

// Chapter 2

// 1
let firstname = "Hassan";
let lastname = "javaid";
let fullname = firstname + lastname;
console.log(fullname);

// 2
let message = "Helo World";
alert(message);

// 4
let studentName = prompt('What is your name?');
let StudentAge = prompt('What is your age?');
alert(`Good! your name is ${studentName} and you are ${StudentAge} years old.`)